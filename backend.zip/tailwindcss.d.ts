declare module 'tailwindcss/lib/util/flattenColorPalette' {
    import { FlattenColorPalette } from 'tailwindcss/types/config';
  
    export default function flattenColorPalette(colors: any): FlattenColorPalette;
  }
  